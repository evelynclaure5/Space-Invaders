using UnityEngine;

public class BalaEnemiga : MonoBehaviour
{
    public float velocidad = 5f;
    public Sprite[] frames;
    public float tiempoFrame = 0.1f;

    SpriteRenderer sr;
    int frameActual = 0;
    float temporizador = 0f;

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        // Caer hacia abajo
        transform.Translate(Vector2.down * velocidad * Time.deltaTime);

        if (transform.position.y < -6f)
        {
            Destroy(gameObject);
        }

        // Animación: pasar al siguiente frame
        temporizador += Time.deltaTime;
        if (temporizador >= tiempoFrame && frames.Length > 0)
        {
            temporizador = 0f;
            frameActual = (frameActual + 1) % frames.Length;
            sr.sprite = frames[frameActual];
        }
    }

    void OnTriggerEnter2D(Collider2D otro)
    {
        Debug.Log("La bala enemiga ha tocado: " + otro.name);
        if (otro.CompareTag("Player"))
        {
            otro.GetComponent<Player>().Impacto();
            Destroy(gameObject);
        }
    }
}