using UnityEngine;

public class Player : MonoBehaviour
{
    public float velocidad = 8f;
    public float limiteX = 8f;
    public GameObject balaPrefab;
    public float cadencia = 0.4f;
    public Sprite spriteExplosion;
    public float tiempoReaparicion = 2f;

    float proximoDisparo;
    bool muerto = false;
    SpriteRenderer sr;
    Collider2D col;
    Sprite spriteNormal;

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
        col = GetComponent<Collider2D>();
        spriteNormal = sr.sprite;
    }

    void Update()
    {
        if (muerto || GameManager.Instance.terminado) return;

        // Movimiento
        float h = Input.GetAxisRaw("Horizontal");
        transform.Translate(Vector2.right * h * velocidad * Time.deltaTime);

        // No salir de la pantalla
        float x = Mathf.Clamp(transform.position.x, -limiteX, limiteX);
        transform.position = new Vector3(x, transform.position.y, 0);

        // Disparo
        if (Input.GetKeyDown(KeyCode.Space) && Time.time >= proximoDisparo)
        {
            Instantiate(balaPrefab, transform.position, Quaternion.identity);
            proximoDisparo = Time.time + cadencia;
        }
    }

    public void Impacto()
    {
        if (muerto) return;

        muerto = true;
        sr.sprite = spriteExplosion;
        col.enabled = false;
        GameManager.Instance.PerderVida();

        if (GameManager.Instance.vidas > 0)
        {
            Invoke("Reaparecer", tiempoReaparicion);
        }
    }

    void Reaparecer()
    {
        muerto = false;
        sr.sprite = spriteNormal;
        col.enabled = true;
        transform.position = new Vector3(0, transform.position.y, 0);
    }
}