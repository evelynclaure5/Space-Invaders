using UnityEngine;

public class Ufo : MonoBehaviour
{
    public float velocidad = 3f;
    public int puntos = 300;
    public float limiteX = 10f;
    public int direccion = 1;   // 1 = derecha, -1 = izquierda

    void Update()
    {
        transform.Translate(Vector2.right * direccion * velocidad * Time.deltaTime);

        // Si se sale de la pantalla, se destruye
        if (Mathf.Abs(transform.position.x) > limiteX)
        {
            Destroy(gameObject);
        }
    }
}