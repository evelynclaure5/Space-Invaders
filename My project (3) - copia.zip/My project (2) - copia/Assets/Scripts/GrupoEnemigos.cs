using UnityEngine;

public class GrupoEnemigos : MonoBehaviour
{
    public GameObject prefabA;
    public GameObject prefabB;
    public GameObject prefabC;
    public GameObject balaEnemigaPrefab;
    public int filas = 4;
    public int columnas = 8;
    public float separacion = 1.4f;
    public float velocidad = 1.5f;
    public float velocidadMaxima = 6f;
    public float limiteX = 8f;
    public float limiteY = -2.5f;
    public float bajada = 0.4f;
    public float intervaloAnimacion = 0.5f;
    public float intervaloAnimacionMin = 0.1f;
    public float intervaloDisparoMax = 1.5f;
    public float intervaloDisparoMin = 0.3f;

    int direccion = 1;
    float temporizador = 0f;
    float temporizadorDisparo;
    int totalInicial;

    void Start()
    {
        for (int f = 0; f < filas; f++)
        {
            for (int c = 0; c < columnas; c++)
            {
                float x = (c - (columnas - 1) / 2f) * separacion;
                float y = 3.5f - f * separacion * 0.8f;
                Instantiate(ElegirPrefab(f), new Vector2(x, y), Quaternion.identity, transform);
            }
        }

        totalInicial = transform.childCount;
        temporizadorDisparo = intervaloDisparoMax;
    }

    GameObject ElegirPrefab(int fila)
    {
        if (fila == 0) return prefabC;                // arriba: 30 pts
        if (fila == 1 || fila == 2) return prefabB;   // medio: 20 pts
        return prefabA;                               // abajo: 10 pts
    }

    // 1 = quedan todos los aliens, cerca de 0 = quedan muy pocos
    float Proporcion()
    {
        return (float)transform.childCount / totalInicial;
    }

    void Update()
    {
        // Victoria: no queda ningún alien
        if (transform.childCount == 0)
        {
            GameManager.Instance.Victoria();
            return;
        }

        Mover();
        Animar();
        Disparar();
    }

    void Mover()
    {
        float velocidadActual = Mathf.Lerp(velocidadMaxima, velocidad, Proporcion());
        transform.Translate(Vector2.right * direccion * velocidadActual * Time.deltaTime);

        foreach (Transform enemigo in transform)
        {
            // Game Over: un alien ha llegado al nivel de los escudos
            if (enemigo.position.y < limiteY)
            {
                GameManager.Instance.GameOver();
                break;
            }

            bool tocaDerecha = enemigo.position.x > limiteX && direccion > 0;
            bool tocaIzquierda = enemigo.position.x < -limiteX && direccion < 0;

            if (tocaDerecha || tocaIzquierda)
            {
                direccion = -direccion;
                transform.Translate(Vector2.down * bajada);
                break;
            }
        }
    }

    void Animar()
    {
        temporizador += Time.deltaTime;
        float intervalo = Mathf.Lerp(intervaloAnimacionMin, intervaloAnimacion, Proporcion());

        if (temporizador >= intervalo)
        {
            temporizador = 0f;
            foreach (Transform enemigo in transform)
            {
                enemigo.GetComponent<Enemigo>().CambiarFrame();
            }
        }
    }

    void Disparar()
    {
        temporizadorDisparo -= Time.deltaTime;

        if (temporizadorDisparo <= 0f)
        {
            int indice = Random.Range(0, transform.childCount);
            Transform alien = transform.GetChild(indice);
            Instantiate(balaEnemigaPrefab, alien.position, Quaternion.identity);

            temporizadorDisparo = Mathf.Lerp(intervaloDisparoMin, intervaloDisparoMax, Proporcion());
        }
    }
}