using UnityEngine;

public class Escudo : MonoBehaviour
{
    public int vida = 8;

    int vidaMaxima;
    Color colorInicial;
    SpriteRenderer sr;

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
        colorInicial = sr.color;
        vidaMaxima = vida;
    }

    void OnTriggerEnter2D(Collider2D otro)
    {
        bool esBalaJugador = otro.GetComponent<Bala>() != null;
        bool esBalaEnemiga = otro.GetComponent<BalaEnemiga>() != null;

        if (esBalaJugador || esBalaEnemiga)
        {
            Destroy(otro.gameObject);
            vida--;

            if (vida <= 0)
            {
                Destroy(gameObject);
            }
            else
            {
                // Cuanta menos vida, más oscuro
                float brillo = Mathf.Lerp(0.35f, 1f, (float)vida / vidaMaxima);
                Color nuevo = colorInicial * brillo;
                nuevo.a = 1f;
                sr.color = nuevo;
            }
        }
    }
}