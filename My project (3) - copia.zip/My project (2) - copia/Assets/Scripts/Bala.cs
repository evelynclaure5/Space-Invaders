using UnityEngine;

public class Bala : MonoBehaviour
{
    public float velocidad = 10f;

    void Update()
    {
        transform.Translate(Vector2.up * velocidad * Time.deltaTime);

        if (transform.position.y > 6f)
        {
            Destroy(gameObject);
        }
    }

    void OnTriggerEnter2D(Collider2D otro)
    {
        if (otro.CompareTag("Enemigo"))
        {
            Enemigo enemigo = otro.GetComponent<Enemigo>();
            GameManager.Instance.SumarPuntos(enemigo.puntos);

            Destroy(otro.gameObject);
            Destroy(gameObject);
        }
        else if (otro.CompareTag("UFO"))
        {
            Ufo ufo = otro.GetComponent<Ufo>();
            GameManager.Instance.SumarPuntos(ufo.puntos);

            Destroy(otro.gameObject);
            Destroy(gameObject);
        }
    }
}