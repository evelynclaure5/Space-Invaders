using UnityEngine;

public class UfoSpawner : MonoBehaviour
{
    public GameObject ufoPrefab;
    public float esperaMin = 8f;
    public float esperaMax = 15f;
    public float altura = 4.3f;

    float temporizador;

    void Start()
    {
        temporizador = Random.Range(esperaMin, esperaMax);
    }

    void Update()
    {
        temporizador -= Time.deltaTime;

        if (temporizador <= 0f)
        {
            Lanzar();
            temporizador = Random.Range(esperaMin, esperaMax);
        }
    }

    void Lanzar()
    {
        // Elegir al azar si entra por la izquierda o por la derecha
        int dir = Random.value < 0.5f ? 1 : -1;
        Vector2 posicion = new Vector2(-10f * dir, altura);

        GameObject ufo = Instantiate(ufoPrefab, posicion, Quaternion.identity);
        ufo.GetComponent<Ufo>().direccion = dir;
    }
}