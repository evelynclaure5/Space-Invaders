using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    public TextMeshProUGUI textoPuntos;
    public TextMeshProUGUI textoVidas;
    public TextMeshProUGUI textoFin;
    public int vidas = 3;
    public bool terminado = false;
    int puntos = 0;

    void Awake()
    {
        Instance = this;
    }

    void Start()
    {
        Time.timeScale = 1f;
        textoFin.gameObject.SetActive(false);
        ActualizarUI();
    }

    void Update()
    {
        // Reiniciar con R cuando la partida ha terminado
        if (terminado && Input.GetKeyDown(KeyCode.R))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }

    public void SumarPuntos(int cantidad)
    {
        puntos += cantidad;
        ActualizarUI();
    }

    public void PerderVida()
    {
        if (terminado) return;

        vidas--;
        ActualizarUI();

        if (vidas <= 0)
        {
            Fin("GAME OVER");
        }
    }

    public void GameOver()
    {
        Fin("GAME OVER");
    }

    public void Victoria()
    {
        Fin("VICTORIA!");
    }

    void Fin(string mensaje)
    {
        if (terminado) return;

        terminado = true;
        textoFin.text = mensaje + "\nPulsa R para reiniciar";
        textoFin.gameObject.SetActive(true);
        Time.timeScale = 0f;
    }

    void ActualizarUI()
    {
        textoPuntos.text = "PUNTOS: " + puntos;
        textoVidas.text = "VIDAS: " + vidas;
    }
}