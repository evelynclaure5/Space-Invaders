using UnityEngine;

public class Enemigo : MonoBehaviour
{
    public Sprite frame1;
    public Sprite frame2;
    public int puntos = 10;

    SpriteRenderer sr;
    bool enFrame1 = true;

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
    }

    public void CambiarFrame()
    {
        enFrame1 = !enFrame1;
        sr.sprite = enFrame1 ? frame1 : frame2;
    }
}